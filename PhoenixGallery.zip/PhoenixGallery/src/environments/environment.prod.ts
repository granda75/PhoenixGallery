
export const environment = {
  production: true,
  apiEndpoint: 'https://localhost:44372/api',
  mvcEndPoint: 'https://localhost:44372/Home'
};


