import { Component, OnInit, Input } from '@angular/core';
import { RepoItem } from '../model/repo-item';
import { GithubService } from '../service/github.service';

//The component responsible to show GitHub repository items as a Gallery

@Component({
  selector: 'app-photo-gallery',
  templateUrl: './photo-gallery.component.html',
  styleUrls: ['./photo-gallery.component.scss']
})
export class PhotoGalleryComponent implements OnInit {

  @Input() repositoryItems: RepoItem[] = null;
  
  constructor(private gitHubservice: GithubService) { }

  ngOnInit(): void {
  }

  bookmark(repoItem: RepoItem): void 
  {
    debugger;
    try
    {
      this.gitHubservice.BookmarkRepoItem(repoItem).subscribe(data => {
        alert("Repository item was bookmarked");     
        console.log("Repository item was bookmarked");
      });
      
    }
    catch(exception)
    {
        alert("Bookmark operation was failed");     
        console.log("Bookmark operation was failed");
    }

  }

  

}
