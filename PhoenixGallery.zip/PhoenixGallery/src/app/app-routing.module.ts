import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { GithubSearchComponent } from './github-search/github-search.component';
import { BookmarksComponent } from './bookmarks/bookmarks.component';
import { AboutComponent } from './about/about.component';

// There are two routes for two screens in the application :
// 1. for  GithubSearchComponent (in includes the PhotoGalleryComponent)
// 2. for BookmarksComponent, to show the bookmarks of GitHub repository items
const routes: Routes = [
  { path:'gallery', component: GithubSearchComponent },
  { path:'bookmarks', component: BookmarksComponent },
  { path:'about', component: AboutComponent }
  
];


@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
