import { Injectable } from '@angular/core';
import { Observable, of, throwError } from 'rxjs';
import { catchError, map, tap } from 'rxjs/operators';
import { RepoItem } from '../model/repo-item';
import { HttpClient, HttpHeaders, HttpErrorResponse } from '@angular/common/http';
import { environment } from '../../environments/environment';

// GithubService is sigleton service for the application.
// The service gets data from the server and updates it.

@Injectable({
  providedIn: 'root'
})
export class GithubService { 

  httpOptions = {
    headers: new HttpHeaders({ 'Content-Type': 'application/json' })
                };

  constructor(private http: HttpClient) { }

  getGitHubRepoItems(repositoryName: string):Observable<RepoItem[]>
  {
    let url = environment.apiEndpoint + `/GitHub/GetGitHub?repositoryName=` + repositoryName;
    return this.http.get<RepoItem[]>(url);
  }

  GetBookmarkedItems():Observable<RepoItem[]>
  {
      let url = environment.apiEndpoint + "/GitHub/GetBookmarkedItems";
      return this.http.get<RepoItem[]>(url).pipe(catchError(this.handleError));
  }

  BookmarkRepoItem(repoItem: RepoItem)
  {
      let url = environment.apiEndpoint + "/GitHub/BookmarkRepoItem";
      return this.http.post(url, repoItem, this.httpOptions).
              pipe(tap((repoItem) => console.log(`repository item bookmarked`)), 
              catchError(this.handleError));
  }

  //The method hadles the error from the service
  handleError(error: HttpErrorResponse) {
    let errorMessage = 'Unknown error!';
    debugger;
    if (error.error instanceof ErrorEvent) 
    {
      // Client-side errors
      errorMessage = `Error: ${error.error.message}`;
    } 
    else 
    {
      // Server-side errors
      errorMessage = `Error Code: ${error.status}\nMessage: ${error.message} `;
    }
    window.alert(errorMessage);
    return throwError(errorMessage);
  }

  

  
}
