import { Component, OnInit } from '@angular/core';
import { GithubService } from '../service/github.service';
import { RepoItem } from '../model/repo-item';


//The component responsible to show bookmarked GitHub repository items

@Component({
  selector: 'app-bookmarks',
  templateUrl: './bookmarks.component.html',
  styleUrls: ['./bookmarks.component.css']
})
export class BookmarksComponent implements OnInit {

  public bookmarkedItems : RepoItem[];
  constructor(private gitHubservice: GithubService) { }

  ngOnInit(): void 
  {
      this.GetBookmarkedItems();
  }

  GetBookmarkedItems():void
  {
        this.gitHubservice.GetBookmarkedItems().subscribe(data=>{
        this.bookmarkedItems = data;
        });
  }

}
