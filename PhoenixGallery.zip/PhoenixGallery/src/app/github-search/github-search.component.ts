import { Component, OnInit, Input } from '@angular/core';
import { GithubService } from '../service/github.service';
import { RepoItem } from '../model/repo-item';

//The component responsible to search GitHub repository items

@Component({
  selector: 'app-github-search',
  templateUrl: './github-search.component.html',
  styleUrls: ['./github-search.component.scss']
})
export class GithubSearchComponent implements OnInit {

  title = 'Phoenix Gallery';
  public repositoryItems : RepoItem[];
  public repoItem:RepoItem = new RepoItem();
  public isRepoNameFull:boolean = true;
  
  constructor(private gitHubservice: GithubService) { }

  ngOnInit(): void {
  }

  repoSearch():void
  {
    debugger;
    
    if (typeof this.repoItem.name != 'undefined' && this.repoItem.name)
    {
      this.gitHubservice.getGitHubRepoItems(this.repoItem.name).subscribe(data=>{
          this.repositoryItems = data;
      });

      this.isRepoNameFull = true;
    }
    else
    {
      this.isRepoNameFull = false;
    }
    
  }

  

  

}
