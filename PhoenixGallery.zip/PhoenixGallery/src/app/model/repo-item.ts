export class RepoItem 
{
    id          : number;
    name        : string;
    avatar_url  : string;
}
